var express = require('express');
var router = express.Router();
var Class = require('../models/class');



router.get('/classes', function(req, res, next) {
    Class.find({}).exec(function(error, results) {
        if (error) {
            return next(error);
        }
        // Respond with valid data
        res.json(results);
    });
});
module.exports = router;
